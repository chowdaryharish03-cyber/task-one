import pytest
from app import create_app, db
from models import Task, Comment

@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    with app.app_context():
        db.create_all()
    return app.test_client()

def test_create_comment(client):
    client.post("/tasks", json={"title": "Task1"})
    res = client.post("/tasks/1/comments",
                      json={"author": "A", "body": "Hello"})
    assert res.status_code == 201
